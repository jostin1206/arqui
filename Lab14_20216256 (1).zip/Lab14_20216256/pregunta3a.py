import random

def verfificar_dentro(x,y):
    valor=0
    #Para saber si un punto está detro de los valores rqueridos
    #Debemos considerar la forma de una circunferencia
    #1=x^2+y^2
    condicion_x= -((1-(x**2))**(1/2))<y<(1-(x**2))**(1/2)
    condicion_y=-((1-(y**2))**(1/2))<x<(1-(y**2))**(1/2)
    if (condicion_x and condicion_y):
        valor=1
    return valor

def calcular_pi(n):
    contador=0
    for _ in range(n):
        valor=0
        x=random.uniform(-1,1)
        y=random.uniform(-1,1)
        valor=verfificar_dentro(x,y)
        if valor:
            contador+=1
    Pi=(contador/n)*4
    print(Pi)

if __name__ == "__main__":
    calcular_pi(10_000_000)